<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Models\UserAnswer;
use App\Http\Controllers\Controller;

class UserAnswerController extends Controller
{
    public function index()
    {
        $data = UserAnswer::with([
            'testAttempt',
            'question',
            'option'
        ])->latest()->get();

        return response()->json($data);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'test_attempt_id' => 'required|exists:test_attempts,id',
            'question_id'     => 'required|exists:questions,id',
            'option_id'       => 'nullable|exists:options,id',
            'essay_answer'    => 'nullable|string',
        ]);

        // Menggunakan updateOrCreate agar tidak duplicate
        $data = UserAnswer::updateOrCreate(
            [
                // Kondisi pencarian (unique)
                'test_attempt_id' => $validated['test_attempt_id'],
                'question_id'     => $validated['question_id'],
            ],
            [
                // Data yang akan diupdate atau diinsert
                'option_id'    => $validated['option_id'],
                'essay_answer' => $validated['essay_answer'],
            ]
        );

        return response()->json([
            'message' => 'Answer saved successfully',
            'data'    => $data
        ]);
    }

    public function byTestAttempt(Request $request, int $testAttemptId)
    {
        $user = $request->user();

        $data = UserAnswer::with([
            'question',
            'option'
        ])
        ->whereHas('testAttempt', function ($q) use ($user, $testAttemptId) {
            $q->where('id', $testAttemptId)
              ->where('user_id', $user->id);
        })
        ->get();

        return response()->json([
            'success' => true,
            'message' => 'Jawaban berhasil diambil',
            'data' => $data
        ]);
    }

    public function show(string $id)
    {
        $data = UserAnswer::with([
            'testAttempt',
            'question',
            'option'
        ])->findOrFail($id);

        return response()->json($data);
    }

    public function update(Request $request, string $id)
    {
        $data = UserAnswer::findOrFail($id);

        $validated = $request->validate([
            'test_attempt_id' => 'required|exists:test_attempts,id',
            'question_id' => 'required|exists:questions,id',
            'option_id' => 'nullable|exists:options,id',
            'essay_answer' => 'nullable',
        ]);

        $data->update($validated);

        return response()->json([
            'message' => 'Answer updated',
            'data' => $data
        ]);
    }

    public function destroy(string $id)
    {
        $data = UserAnswer::findOrFail($id);

        $data->delete();

        return response()->json([
            'message' => 'Answer deleted'
        ]);
    }
}
