<?php

namespace App\Http\Controllers\Api;

use App\Models\Option;
use App\Models\Question;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class QuestionController extends Controller
{
    public function index()
    {
        $questions = Question::with('options')
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Data question berhasil diambil',
            'data' => $questions
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'test_id' => 'required|exists:tests,id',
            'question_text' => 'required|string',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'type' => 'required|in:PG,ES,IP,PW',
            'duration' => 'nullable|integer',
            'point' => 'nullable|integer',
            'order' => 'nullable|integer',

            'options' => 'nullable|array',
            'options.*.label' => 'required|string|max:5',
            'options.*.option_text' => 'required|string',
            'options.*.is_correct' => 'required|boolean',
            'options.*.point' => 'nullable|integer',
        ]);

        if ($request->hasFile('image')) {

            $file = $request->file('image');

            $filename = time() . '_' . $file->getClientOriginalName();

            $path = $file->storeAs(
                'questions',
                $filename,
                'public'
            );

            $validated['image'] = $path;
        }

        $question = Question::create([
            'test_id' => $validated['test_id'],
            'question_text' => $validated['question_text'],
            'image' => $validated['image'] ?? null,
            'type' => $validated['type'],
            'duration' => $validated['duration'] ?? null,
            'point' => $validated['point'] ?? 0,
            'order' => $validated['order'] ?? 0,
        ]);

        if (!empty($validated['options'])) {

            foreach ($validated['options'] as $item) {

                $question->options()->create([
                'label' => $item['label'],
                'option_text' => $item['option_text'],
                'is_correct' => $item['is_correct'],
                'point' => $item['point'] ?? 0,
            ]);
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Question berhasil dibuat',
            'data' => $question->load('options')
        ], 201);
    }

    public function show(string $id)
    {
        $question = Question::with('options')
            ->findOrFail($id);

        return response()->json([
            'success' => true,
            'message' => 'Detail question berhasil diambil',
            'data' => $question
        ]);
    }

    public function update(Request $request, string $id)
{
    $question = Question::findOrFail($id);

    $validated = $request->validate([
        'test_id' => 'required|exists:tests,id',
        'question_text' => 'required|string',

        // nullable supaya bisa kosong saat delete
        'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',

        'type' => 'required|in:PG,ES,IP,PW',
        'duration' => 'nullable|integer',
        'point' => 'nullable|integer',
        'order' => 'nullable|integer',

        'options' => 'nullable|array',
        'options.*.label' => 'required|string|max:5',
        'options.*.option_text' => 'required|string',
        'options.*.is_correct' => 'required|boolean',
        'options.*.point' => 'nullable|integer',
    ]);

    /**
     * IMAGE HANDLER
     *
     * CASE:
     * 1. Upload image baru -> replace
     * 2. image dikirim kosong -> delete image
     * 3. image tidak dikirim -> keep image lama
     */

    // default keep image lama
    $validated['image'] = $question->image;

    // upload image baru
    if ($request->hasFile('image')) {

        // hapus file lama
        if (
            $question->image &&
            Storage::disk('public')->exists($question->image)
        ) {
            Storage::disk('public')->delete($question->image);
        }

        $file = $request->file('image');

        $filename = time() . '_' . $file->getClientOriginalName();

        $path = $file->storeAs(
            'questions',
            $filename,
            'public'
        );

        $validated['image'] = $path;
    }

    // delete image
    elseif ($request->has('image') && empty($request->image)) {

        if (
            $question->image &&
            Storage::disk('public')->exists($question->image)
        ) {
            Storage::disk('public')->delete($question->image);
        }

        $validated['image'] = null;
    }

    $question->update([
        'test_id' => $validated['test_id'],
        'question_text' => $validated['question_text'],
        'image' => $validated['image'],
        'type' => $validated['type'],
        'duration' => $validated['duration'] ?? null,
        'point' => $validated['point'] ?? 0,
        'order' => $validated['order'] ?? 0,
    ]);

    // update options
    if (!empty($validated['options'])) {

        $question->options()->delete();

        foreach ($validated['options'] as $item) {

            $question->options()->create([
                'label' => $item['label'],
                'option_text' => $item['option_text'],
                'is_correct' => $item['is_correct'],
                'point' => $item['point'] ?? 0,
            ]);
        }
    }

    return response()->json([
        'success' => true,
        'message' => 'Question berhasil diupdate',
        'data' => $question->load('options')
    ]);
}

    public function destroy(string $id)
    {
        $question = Question::findOrFail($id);

        $question->delete();

        return response()->json([
            'success' => true,
            'message' => 'Question berhasil dihapus'
        ]);
    }
}
