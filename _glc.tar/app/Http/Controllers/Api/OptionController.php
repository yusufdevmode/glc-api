<?php

namespace App\Http\Controllers\Api;

use App\Models\Option;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OptionController extends Controller
{
    public function index()
    {
        $options = Option::latest()->get();

        return response()->json($options);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'question_id' => 'required|exists:questions,id',
            'label' => 'required',
            'option_text' => 'nullable',
            'image' => 'nullable',
            'is_correct' => 'boolean',
        ]);

        $option = Option::create($validated);

        return response()->json([
            'message' => 'Option created',
            'data' => $option
        ]);
    }

    public function show(string $id)
    {
        $option = Option::findOrFail($id);

        return response()->json($option);
    }

    public function update(Request $request, string $id)
    {
        $option = Option::findOrFail($id);

        $validated = $request->validate([
            'question_id' => 'required|exists:questions,id',
            'label' => 'required',
            'option_text' => 'nullable',
            'image' => 'nullable',
            'is_correct' => 'boolean',
        ]);

        $option->update($validated);

        return response()->json([
            'message' => 'Option updated',
            'data' => $option
        ]);
    }

    public function destroy(string $id)
    {
        $option = Option::findOrFail($id);

        $option->delete();

        return response()->json([
            'message' => 'Option deleted'
        ]);
    }
}
